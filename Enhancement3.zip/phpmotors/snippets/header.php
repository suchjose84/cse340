<header>
    <div id="logoImage"><a href="http://localhost/cse340/phpmotors/"><img src="/cse340/phpmotors/images/site/logo.png" alt="logoImg"></a></div>
    <div id="myAccountText"><a href="http://localhost/cse340/phpmotors/accounts/?action=login">My Account</a></div>
</header>