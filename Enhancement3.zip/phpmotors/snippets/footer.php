<footer>
    <ul>
        <li>&#169; PHP Motors, All rights reserved.</li>
        <li>All images used are believed to be in "Fair Use". Please notify the author if any are not
            and they will be removed.
        </li>
        <li>Last Updated: 30 March, 2018</li>
    </ul>
</footer>